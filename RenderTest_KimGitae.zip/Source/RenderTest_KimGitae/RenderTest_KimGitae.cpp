// Copyright Epic Games, Inc. All Rights Reserved.

#include "RenderTest_KimGitae.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, RenderTest_KimGitae, "RenderTest_KimGitae" );
