// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "RenderTest_KimGitaeGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class RENDERTEST_KIMGITAE_API ARenderTest_KimGitaeGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
