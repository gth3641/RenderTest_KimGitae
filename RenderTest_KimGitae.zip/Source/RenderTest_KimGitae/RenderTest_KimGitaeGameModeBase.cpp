// Copyright Epic Games, Inc. All Rights Reserved.


#include "RenderTest_KimGitaeGameModeBase.h"

