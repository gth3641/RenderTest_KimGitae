안녕하십니까. 렌더링 테크 엔지니어 지원자 김기태 입니다.

프로젝트 실행을 위해 아래 단계를 따라 주시면 감사하겠습니다.

1. 'RenderTest_KimGitae.uproject' 오른쪽 마우스 클릭
2. 'Generate Visual Studio project files' 클릭 (솔루션 파일 확인 가능해집니다.)
3. 'RenderTest_KimGitae.uproject' 클릭으로 Unreal Engine 4.25 실행

감사합니다.

생성된 스크립트 이름
-IndirectTexture.h
-MatExprIndirTexSample.h